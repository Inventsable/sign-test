 <template>
  <span>Hello world</span>
</template>
 
<script>
const fs = require('fs')
import untildify from "untildify";
// import download from "download";
import recorder from "mic-recorder-to-mp3";

export default {
  mounted() {
    console.log(untildify);
    console.log(recorder);
    console.log(fs);

    // Throws errors:
    //   1) Claims electron is missing as npm dependency and prompts for install
    //   2)  warning in ./node_modules/keyv/src/index.js
    //       Critical dependency: the request of a dependency is an expression
    // 
    //      In console: Path must be a string. Received undefined at assertPath (path.js:28)
    // console.log(download);
  }
};
</script>
